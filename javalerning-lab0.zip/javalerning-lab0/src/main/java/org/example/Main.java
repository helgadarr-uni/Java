package org.example;

import lab1.Car;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }

}




